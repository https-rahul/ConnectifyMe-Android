package application.rahul.connectifyme.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import application.rahul.connectifyme.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
