<?php
require  __DIR__ .  '/../vendor/autoload.php';
$app = new \Slim\App();
include __DIR__ .'/../app/user.php';
?>